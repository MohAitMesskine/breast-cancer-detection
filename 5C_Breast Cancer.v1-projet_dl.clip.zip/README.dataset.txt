# 5C_Breast Cancer > projet_dl
https://universe.roboflow.com/med-qhtrw/5c_breast-cancer-cgbl1

Provided by a Roboflow user
License: Public Domain

